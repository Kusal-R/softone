using TaskManagementDataAccess;
using TaskManagementService;

var builder = WebApplication.CreateBuilder(args);

// Add services to the container.
// Services
builder.Services.AddSingleton<ITaskManagementApplicationService, TaskManagementApplicationService>();
// Data access 
builder.Services.AddSingleton<ITaskManagementApplicationDataAccess, TaskManagementApplicationDataAccess>();

// CORS Policy
builder.Services.AddCors(options =>
{
    options.AddPolicy("CorsPolicy", policy =>
    {
        policy.WithOrigins("http://localhost:4200") // Replace with your Angular app URL
              .AllowAnyHeader()
              .AllowAnyMethod();
    });
});

// Adding the Json options
builder.Services.AddMvc().AddJsonOptions(o =>
{
    o.JsonSerializerOptions.PropertyNamingPolicy = null;
    o.JsonSerializerOptions.DictionaryKeyPolicy = null;
});

builder.Services.AddControllers();
// Learn more about configuring Swagger/OpenAPI at https://aka.ms/aspnetcore/swashbuckle
builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen();

var app = builder.Build();

// Configure the HTTP request pipeline.
if (app.Environment.IsDevelopment())
{
    app.UseSwagger();
    app.UseSwaggerUI();
}

app.UseHttpsRedirection();

// Enable CORS before Authorization
app.UseCors("CorsPolicy");
app.UseStaticFiles();

app.UseAuthorization();

app.MapControllers();

app.Run();
