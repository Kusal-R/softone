﻿using Microsoft.AspNetCore.Mvc;
using TaskManagementApplicationModels;
using TaskManagementService;

// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace TaskManagementApplication.Controllers
{
    [Route("api/taskmanager")]
    [ApiController]
    public class TaskManagementController : Controller
    {
        // read only attributes
        private readonly ITaskManagementApplicationService _itaskManagementApplicationService;

        // constructor
        public TaskManagementController(ITaskManagementApplicationService taskManagementApplicationService)
        {
            // Initialize
            this._itaskManagementApplicationService = taskManagementApplicationService;
        }


        /// <summary>
        /// Get All Tasks
        /// </summary>
        /// <returns></returns>
        [HttpGet]
        [Route("GetAllTasks")]
        public IActionResult GetAllTasks()
        {
            try
            {
                // get tasks list
                var response = _itaskManagementApplicationService.GetAllTasks();
                return Json(response);
            }
            catch (Exception ex)
            {
                //Returning the exception
                return Json("System Failed: " + ex.Message);
            }
        }


        /// <summary>
        /// GetAllTasksById
        /// </summary>
        /// <param name="taskId"></param>
        /// <returns></returns>
        [HttpGet]
        [Route("GetAllTasksById")]
        public IActionResult GetAllTasksById(int taskId)
        {
            try
            {
                // get tasks list
                var response = _itaskManagementApplicationService.GetAllTasksById(taskId);
                return Json(response);
            }
            catch (Exception ex)
            {
                //Returning the exception
                return Json("System Failed: " + ex.Message);
            }
        }

        /// <summary>
        /// set tasks
        /// </summary>
        /// <param name="taskManager"></param>
        /// <returns></returns>
        [HttpPost]
        [Route("SetTasks")]
        public IActionResult SetTasks([FromBody] TaskManager taskManager)
        {
            try
            {
                // get tasks list
                var response = _itaskManagementApplicationService.SetTasks(taskManager);
                return Json(response);
            }
            catch (Exception ex)
            {
                //Returning the exception
                return Json("System Failed: " + ex.Message);
            }
        }

        /// <summary>
        /// RemoveTasksById
        /// </summary>
        /// <param name="taskId"></param>
        /// <returns></returns>
        [HttpGet]
        [Route("RemoveTasksById")]
        public IActionResult RemoveTasksById(int taskId)
        {
            try
            {
                // get tasks list
                var response = _itaskManagementApplicationService.RemoveTasksById(taskId);
                return Json(response);
            }
            catch (Exception ex)
            {
                //Returning the exception
                return Json("System Failed: " + ex.Message);
            }
        }


        /// <summary>
        /// CompleteTasksById
        /// </summary>
        /// <param name="taskId"></param>
        /// <returns></returns>
        [HttpGet]
        [Route("CompleteTasksById")]
        public IActionResult CompleteTasksById(int taskId)
        {
            try
            {
                // get tasks list
                var response = _itaskManagementApplicationService.CompleteTasksById(taskId);
                return Json(response);
            }
            catch (Exception ex)
            {
                //Returning the exception
                return Json("System Failed: " + ex.Message);
            }
        }


        /// <summary>
        /// ValidateUser
        /// </summary>
        /// <param name="userId"></param>
        /// <param name="password"></param>
        /// <returns></returns>
        [HttpGet]
        [Route("ValidateUser")]
        public IActionResult ValidateUser(string userId,string password)
        {
            try
            {
                // get tasks list
                var response = _itaskManagementApplicationService.ValidateUser(userId,password);
                return Json(response);
            }
            catch (Exception ex)
            {
                //Returning the exception
                return Json("System Failed: " + ex.Message);
            }
        }

        [HttpGet]
        [Route("GetSortAllTasks")]
        public IActionResult GetSortAllTasks(string columnName,string sortType)
        {
            try
            {
                // get tasks list
                var response = _itaskManagementApplicationService.GetSortAllTasks(columnName,sortType);
                return Json(response);
            }
            catch (Exception ex)
            {
                //Returning the exception
                return Json("System Failed: " + ex.Message);
            }
        }


    }
}
