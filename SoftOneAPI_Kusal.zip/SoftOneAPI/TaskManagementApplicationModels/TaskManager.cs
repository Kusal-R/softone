﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TaskManagementApplicationModels
{
    public class TaskManager
    {
        public int Id { get; set; }                       // Primary Key
        public string Title { get; set; } = string.Empty; // Task title
        public string? Description { get; set; }          // Optional detailed description
        public bool IsCompleted { get; set; }             // Status: done or not
        public DateTime CreatedDate { get; set; }           // When the task was created
        public DateTime? DueDate { get; set; }            // Optional due date        
    }
}
