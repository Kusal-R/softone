﻿using TaskManagementApplicationModels;
using TaskManagementDataAccess;

namespace TaskManagementService
{
    public class TaskManagementApplicationService : ITaskManagementApplicationService
    {
        // read only attributes
        private readonly ITaskManagementApplicationDataAccess _itaskManagementApplicationDataAccess;
            
        // Constructor
        public TaskManagementApplicationService(ITaskManagementApplicationDataAccess itaskManagementApplicationDataAccess) 
        {
            // Initializing
            this._itaskManagementApplicationDataAccess = itaskManagementApplicationDataAccess;
        }

        /// <summary>
        /// CompleteTasksById
        /// </summary>
        /// <param name="taskId"></param>
        /// <returns></returns>
        public bool CompleteTasksById(int taskId)
        {
            return this._itaskManagementApplicationDataAccess.CompleteTasksById(taskId);
        }


        /// <summary>
        /// Get All Tasks
        /// </summary>
        /// <returns></returns>
        public List<TaskManager> GetAllTasks()
        {
            return this._itaskManagementApplicationDataAccess.GetAllTasks();
        }


        /// <summary>
        /// GetAllTasksById
        /// </summary>
        /// <param name="taskId"></param>
        /// <returns></returns>
        public TaskManager GetAllTasksById(int taskId)
        {
            return this._itaskManagementApplicationDataAccess.GetAllTasksById(taskId);
        }

        public List<TaskManager> GetSortAllTasks(string columnName, string sortType)
        {
            return this._itaskManagementApplicationDataAccess.GetSortAllTasks(columnName, sortType);
        }

        /// <summary>
        /// RemoveTasksById
        /// </summary>
        /// <param name="taskId"></param>
        /// <returns></returns>
        public bool RemoveTasksById(int taskId)
        {
            return this._itaskManagementApplicationDataAccess.RemoveTasksById(taskId);
        }

        /// <summary>
        /// set tasks
        /// </summary>
        /// <param name="taskManager"></param>
        /// <returns></returns>
        public bool SetTasks(TaskManager taskManager)
        {
            return this._itaskManagementApplicationDataAccess.SetTasks(taskManager);
        }

        /// <summary>
        /// ValidateUser
        /// </summary>
        /// <param name="userId"></param>
        /// <param name="password"></param>
        /// <returns></returns>
        public bool ValidateUser(string userId, string password)
        {
            return this._itaskManagementApplicationDataAccess.ValidateUser(userId,password);
        }
    }
}
