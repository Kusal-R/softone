﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TaskManagementApplicationModels;

namespace TaskManagementService
{
    public interface ITaskManagementApplicationService
    {
        /// <summary>
        /// Get All Tasks
        /// </summary>
        /// <returns></returns>
        List<TaskManager> GetAllTasks();

        /// <summary>
        /// set tasks
        /// </summary>
        /// <param name="taskManager"></param>
        /// <returns></returns>
        bool SetTasks(TaskManager taskManager);

        /// <summary>
        /// GetAllTasksById
        /// </summary>
        /// <param name="taskId"></param>
        /// <returns></returns>
        TaskManager GetAllTasksById(int taskId);

        /// <summary>
        /// RemoveTasksById
        /// </summary>
        /// <param name="taskId"></param>
        /// <returns></returns>
        bool RemoveTasksById(int taskId);

        /// <summary>
        /// CompleteTasksById
        /// </summary>
        /// <param name="taskId"></param>
        /// <returns></returns>
        bool CompleteTasksById(int taskId);

        /// <summary>
        /// ValidateUser
        /// </summary>
        /// <param name="userId"></param>
        /// <param name="password"></param>
        /// <returns></returns>
        bool ValidateUser(string userId, string password);
        List<TaskManager> GetSortAllTasks(string columnName, string sortType);
    }
}
