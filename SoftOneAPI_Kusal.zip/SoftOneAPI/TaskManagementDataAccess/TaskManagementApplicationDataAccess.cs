﻿using Microsoft.Extensions.Configuration;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TaskManagementApplicationModels;

namespace TaskManagementDataAccess
{
    public class TaskManagementApplicationDataAccess : ITaskManagementApplicationDataAccess
    {
        // read only attributes
        private readonly IConfiguration _iconfiguration;
        // Constructor
        public TaskManagementApplicationDataAccess(IConfiguration iconfiguration)
        {
            // Initializing
            this._iconfiguration = iconfiguration;
        }

        /// <summary>
        /// CompleteTasksById
        /// </summary>
        /// <param name="taskId"></param>
        /// <returns></returns>
        public bool CompleteTasksById(int taskId)
        {
            // return status
            bool status = false;

            // exception handling
            try
            {
                //Setting the SQL connection with the connection string
                using (SqlConnection connection = new SqlConnection(_iconfiguration.GetConnectionString("DefaultDB")))
                {
                    //Openning the connection
                    connection.Open();

                    //Specifing the name of the SP
                    using (SqlCommand sqlCommand = new SqlCommand("[dbo].[SetTasks]", connection) { CommandType = CommandType.StoredProcedure })
                    {
                        // Passing parameters                                                
                        SqlParameter ActionParameter = sqlCommand.Parameters.Add("@Action", SqlDbType.VarChar, 50);
                        ActionParameter.Value = "TASK$COMPLETE";

                        SqlParameter IdParameter = sqlCommand.Parameters.Add("@Id", SqlDbType.NVarChar, 255);
                        IdParameter.Value = taskId;


                        //Executing the sql SP command
                        var result = sqlCommand.ExecuteReader();

                        //Iterating through the result    
                        while (result.Read())
                        {
                            if (Convert.ToInt32(result["Result"].ToString()) > 0)
                            {
                                status = true;
                            }
                        }
                    }

                    //Closing the connection
                    connection.Close();

                }
            }
            catch (Exception ex)
            {
                throw new Exception("Error in RemoveTasksById ! :" + ex);
            }

            return status;
        }

        /// <summary>
        /// Get All Tasks
        /// </summary>
        /// <returns></returns>
        public List<TaskManager> GetAllTasks()
        {
            // return list
            List<TaskManager> taskList = new List<TaskManager>();

            // exception handling
            try
            {
                //Setting the SQL connection with the connection string
                using (SqlConnection connection = new SqlConnection(_iconfiguration.GetConnectionString("DefaultDB")))
                {
                    //Openning the connection
                    connection.Open();

                    //Specifing the name of the SP
                    using (SqlCommand sqlCommand = new SqlCommand("[dbo].[GetAllTasks]", connection) { CommandType = CommandType.StoredProcedure })
                    {
                        // Passing parameters                                                
                        SqlParameter ActionParameter = sqlCommand.Parameters.Add("@Action", SqlDbType.VarChar, 50);
                        ActionParameter.Value = "GET$ALL";

                        //Executing the sql SP command
                        var result = sqlCommand.ExecuteReader();

                        //Iterating through the result    
                        while (result.Read())
                        {
                            taskList.Add(new TaskManager()
                            {
                                Id = Convert.ToInt32(result["Id"].ToString()),
                                Title = result["Title"].ToString(),
                                Description = result["Description"].ToString(),
                                CreatedDate = Convert.ToDateTime(result["CreatedDate"].ToString()),
                                DueDate = Convert.ToDateTime(result["DueDate"].ToString()),
                                IsCompleted = Convert.ToBoolean(result["IsCompleted"].ToString())
                            });
                        }
                    }

                    //Closing the connection
                    connection.Close();

                }
            }
            catch (Exception ex)
            {
                throw new Exception("Error in GetAllTasks ! :" + ex);
            }

            return taskList;
        }


        /// <summary>
        /// GetAllTasksById
        /// </summary>
        /// <param name="taskId"></param>
        /// <returns></returns>
        public TaskManager GetAllTasksById(int taskId)
        {
            // return list
            TaskManager taskManager = new TaskManager();

            // exception handling
            try
            {
                //Setting the SQL connection with the connection string
                using (SqlConnection connection = new SqlConnection(_iconfiguration.GetConnectionString("DefaultDB")))
                {
                    //Openning the connection
                    connection.Open();

                    //Specifing the name of the SP
                    using (SqlCommand sqlCommand = new SqlCommand("[dbo].[GetAllTasks]", connection) { CommandType = CommandType.StoredProcedure })
                    {
                        // Passing parameters                                                
                        SqlParameter ActionParameter = sqlCommand.Parameters.Add("@Action", SqlDbType.VarChar, 50);
                        ActionParameter.Value = "GET$BYID";

                        SqlParameter TaskIdParameter = sqlCommand.Parameters.Add("@TaskId", SqlDbType.Int);
                        TaskIdParameter.Value = taskId;

                        //Executing the sql SP command
                        var result = sqlCommand.ExecuteReader();

                        //Iterating through the result    
                        while (result.Read())
                        {
                            taskManager.Id = Convert.ToInt32(result["Id"].ToString());
                            taskManager.Title = result["Title"].ToString();
                            taskManager.Description = result["Description"].ToString();
                            taskManager.CreatedDate = Convert.ToDateTime(result["CreatedDate"].ToString());
                            taskManager.DueDate = Convert.ToDateTime(result["DueDate"].ToString());
                            taskManager.IsCompleted = Convert.ToBoolean(result["IsCompleted"].ToString());                            
                        }
                    }

                    //Closing the connection
                    connection.Close();

                }
            }
            catch (Exception ex)
            {
                throw new Exception("Error in GetAllTasks ! :" + ex);
            }

            return taskManager;
        }

        public List<TaskManager> GetSortAllTasks(string columnName, string sortType)
        {
            // return list
            List<TaskManager> taskList = new List<TaskManager>();

            // exception handling
            try
            {
                //Setting the SQL connection with the connection string
                using (SqlConnection connection = new SqlConnection(_iconfiguration.GetConnectionString("DefaultDB")))
                {
                    //Openning the connection
                    connection.Open();

                    //Specifing the name of the SP
                    using (SqlCommand sqlCommand = new SqlCommand("[dbo].[GetAllTasks]", connection) { CommandType = CommandType.StoredProcedure })
                    {
                        // Passing parameters                                                
                        SqlParameter ActionParameter = sqlCommand.Parameters.Add("@Action", SqlDbType.VarChar, 50);
                        ActionParameter.Value = "GET$SORT$DATA";

                        SqlParameter ColumnNameParameter = sqlCommand.Parameters.Add("@ColumnName", SqlDbType.VarChar, 50);
                        ColumnNameParameter.Value = columnName;

                        SqlParameter SortByParameter = sqlCommand.Parameters.Add("@SortBy", SqlDbType.VarChar, 50);
                        SortByParameter.Value = sortType;

                        //Executing the sql SP command
                        var result = sqlCommand.ExecuteReader();

                        //Iterating through the result    
                        while (result.Read())
                        {
                            taskList.Add(new TaskManager()
                            {
                                Id = Convert.ToInt32(result["Id"].ToString()),
                                Title = result["Title"].ToString(),
                                Description = result["Description"].ToString(),
                                CreatedDate = Convert.ToDateTime(result["CreatedDate"].ToString()),
                                DueDate = Convert.ToDateTime(result["DueDate"].ToString()),
                                IsCompleted = Convert.ToBoolean(result["IsCompleted"].ToString())
                            });
                        }
                    }

                    //Closing the connection
                    connection.Close();

                }
            }
            catch (Exception ex)
            {
                throw new Exception("Error in GetAllTasks ! :" + ex);
            }

            return taskList;
        }

        /// <summary>
        /// RemoveTasksById
        /// </summary>
        /// <param name="taskId"></param>
        /// <returns></returns>
        public bool RemoveTasksById(int taskId)
        {
            // return status
            bool status = false;

            // exception handling
            try
            {
                //Setting the SQL connection with the connection string
                using (SqlConnection connection = new SqlConnection(_iconfiguration.GetConnectionString("DefaultDB")))
                {
                    //Openning the connection
                    connection.Open();

                    //Specifing the name of the SP
                    using (SqlCommand sqlCommand = new SqlCommand("[dbo].[SetTasks]", connection) { CommandType = CommandType.StoredProcedure })
                    {
                        // Passing parameters                                                
                        SqlParameter ActionParameter = sqlCommand.Parameters.Add("@Action", SqlDbType.VarChar, 50);
                       ActionParameter.Value = "REMOVE$TASK";                       

                        SqlParameter IdParameter = sqlCommand.Parameters.Add("@Id", SqlDbType.NVarChar, 255);
                        IdParameter.Value = taskId;
                        

                        //Executing the sql SP command
                        var result = sqlCommand.ExecuteReader();

                        //Iterating through the result    
                        while (result.Read())
                        {
                            if (Convert.ToInt32(result["Result"].ToString()) > 0)
                            {
                                status = true;
                            }
                        }
                    }

                    //Closing the connection
                    connection.Close();

                }
            }
            catch (Exception ex)
            {
                throw new Exception("Error in RemoveTasksById ! :" + ex);
            }

            return status;
        }

        /// <summary>
        /// set tasks
        /// </summary>
        /// <param name="taskManager"></param>
        /// <returns></returns>
        public bool SetTasks(TaskManager taskManager)
        {
            // return status
            bool status = false;

            // exception handling
            try
            {
                //Setting the SQL connection with the connection string
                using (SqlConnection connection = new SqlConnection(_iconfiguration.GetConnectionString("DefaultDB")))
                {
                    //Openning the connection
                    connection.Open();

                    //Specifing the name of the SP
                    using (SqlCommand sqlCommand = new SqlCommand("[dbo].[SetTasks]", connection) { CommandType = CommandType.StoredProcedure })
                    {
                        // Passing parameters                                                
                        SqlParameter ActionParameter = sqlCommand.Parameters.Add("@Action", SqlDbType.VarChar, 50);
                        if (taskManager.Id > 0)
                        {
                            ActionParameter.Value = "EDIT";
                        }
                        else
                        {
                            ActionParameter.Value = "SET";
                        }

                        SqlParameter IdParameter = sqlCommand.Parameters.Add("@Id", SqlDbType.NVarChar, 255);
                        IdParameter.Value = taskManager.Id;

                        SqlParameter TitleParameter = sqlCommand.Parameters.Add("@Title", SqlDbType.NVarChar, 255);
                        TitleParameter.Value = taskManager.Title;

                        SqlParameter DescriptionParameter = sqlCommand.Parameters.Add("@Description", SqlDbType.NVarChar);
                        DescriptionParameter.Value = taskManager.Description;

                        SqlParameter CreatedDateParameter = sqlCommand.Parameters.Add("@CreatedDate", SqlDbType.VarChar, 50);
                        CreatedDateParameter.Value = taskManager.CreatedDate;

                        SqlParameter DueDateParameter = sqlCommand.Parameters.Add("@DueDate", SqlDbType.VarChar, 50);
                        DueDateParameter.Value = taskManager.DueDate;

                        SqlParameter IsCompletedParameter = sqlCommand.Parameters.Add("@IsCompleted", SqlDbType.Bit);
                        IsCompletedParameter.Value = taskManager.IsCompleted;

                        //Executing the sql SP command
                        var result = sqlCommand.ExecuteReader();

                        //Iterating through the result    
                        while (result.Read())
                        {
                            if( Convert.ToInt32(result["Result"].ToString()) > 0)
                            {
                                status = true;
                            }                            
                        }
                    }

                    //Closing the connection
                    connection.Close();

                }
            }
            catch (Exception ex)
            {
                throw new Exception("Error in SetTasks ! :" + ex);
            }

            return status;
        }

        /// <summary>
        /// ValidateUser
        /// </summary>
        /// <param name="userId"></param>
        /// <param name="password"></param>
        /// <returns></returns>
        public bool ValidateUser(string userId, string password)
        {
            // return status
            bool status = false;

            // exception handling
            try
            {
                //Setting the SQL connection with the connection string
                using (SqlConnection connection = new SqlConnection(_iconfiguration.GetConnectionString("DefaultDB")))
                {
                    //Openning the connection
                    connection.Open();

                    //Specifing the name of the SP
                    using (SqlCommand sqlCommand = new SqlCommand("[dbo].[GetLoginDetails]", connection) { CommandType = CommandType.StoredProcedure })
                    {
                        // Passing parameters                                                                       

                        SqlParameter UserNameParameter = sqlCommand.Parameters.Add("@UserName", SqlDbType.NVarChar, 50);
                        UserNameParameter.Value = userId;

                        SqlParameter PasswordParameter = sqlCommand.Parameters.Add("@Password", SqlDbType.NVarChar,50);
                        PasswordParameter.Value = password;                        

                        //Executing the sql SP command
                        var result = sqlCommand.ExecuteReader();

                        //Iterating through the result    
                        while (result.Read())
                        {
                            status = Convert.ToBoolean(result["Result"].ToString());                            
                        }
                    }

                    //Closing the connection
                    connection.Close();

                }
            }
            catch (Exception ex)
            {
                throw new Exception("Error in ValidateUser ! :" + ex);
            }

            return status;
        }
    }
}
