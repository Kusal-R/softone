﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TaskManagementApplicationModels;

namespace TaskManagementDataAccess
{
    public interface ITaskManagementApplicationDataAccess
    {
        /// <summary>
        /// Get All Tasks
        /// </summary>
        /// <returns></returns>
        List<TaskManager> GetAllTasks();

        /// <summary>
        /// set tasks
        /// </summary>
        /// <param name="taskManager"></param>
        /// <returns></returns>
        bool SetTasks(TaskManager taskManager);

        /// <summary>
        /// CompleteTasksById
        /// </summary>
        /// <param name="taskId"></param>
        /// <returns></returns>
        bool CompleteTasksById(int taskId);

        /// <summary>
        /// GetAllTasksById
        /// </summary>
        /// <param name="taskId"></param>
        /// <returns></returns>
        TaskManager GetAllTasksById(int taskId);

        /// <summary>
        /// RemoveTasksById
        /// </summary>
        /// <param name="taskId"></param>
        /// <returns></returns>
        bool RemoveTasksById(int taskId);

        /// <summary>
        /// ValidateUser
        /// </summary>
        /// <param name="userId"></param>
        /// <param name="password"></param>
        /// <returns></returns>
        bool ValidateUser(string userId, string password);
        List<TaskManager> GetSortAllTasks(string columnName, string sortType);
    }
}
