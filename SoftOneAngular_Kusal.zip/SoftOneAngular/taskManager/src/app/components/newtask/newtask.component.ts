import { Component, EventEmitter, Input, OnInit, Output } from '@angular/core';
import { Router } from '@angular/router';
import { TaskManager } from 'src/app/models/taskManager';
import { TaskmanagerService } from 'src/app/services/taskmanager.service';

@Component({
  selector: 'app-newtask',
  templateUrl: './newtask.component.html',
  styleUrls: ['./newtask.component.scss'],
})
export class NewtaskComponent implements OnInit {
  // task object
  taskManager: TaskManager = {
    Id: 0,
    Title: '',
    Description: '',
    CreatedDate: '',
    DueDate: '',
    IsCompleted: false,
  };

  // save task
  isSave: boolean = false;
  isValidation: boolean = false;

  // emitter
  @Output() messageEvent = new EventEmitter<boolean>();
  // input
  @Input() taskId: number = 0;
  // edit task
  taskManagerEdit: TaskManager | undefined;

  constructor(private taskmanagerService: TaskmanagerService) {}

  ngOnInit(): void {
    // edit task
    if (this.taskId > 0) {
      //console.log('Edit task');
      this.taskmanagerService.GetTaskById(this.taskId).subscribe((data) => {
        this.taskManagerEdit = <TaskManager>data;
        if (this.taskManagerEdit) {
          this.taskManager = {
            Id: this.taskManagerEdit.Id,
            Title: this.taskManagerEdit.Title,
            Description: this.taskManagerEdit.Description,
            CreatedDate: this.formatDate(this.taskManagerEdit.CreatedDate),
            DueDate: this.formatDate(this.taskManagerEdit.DueDate),
            IsCompleted: this.taskManagerEdit.IsCompleted,
          };
        }
      });
    }
  }

  // save task
  saveTask() {
    // validation
    if (this.taskManager.Title == '') {
      // validation enable
      this.isValidation = true;
      return;
    }
    if (this.taskManager.Description == '') {
      // validation enable
      this.isValidation = true;
      return;
    }
    if (this.taskManager.CreatedDate == '') {
      // validation enable
      this.isValidation = true;
      return;
    }
    if (this.taskManager.DueDate == '') {
      // validation enable
      this.isValidation = true;
      return;
    }
    // pass data to API
    this.taskmanagerService.SaveTask(this.taskManager).subscribe((data) => {
      if (data) {
        this.isSave = <boolean>data;
        if (this.isSave) {
          this.messageEvent.emit(false);
        }
      }
    });
  }

  // cancel task screen
  cancelTask() {
    this.messageEvent.emit(false);
  }

  // validate due date
  isDueDateValid(): boolean {
    if (!this.taskManager.DueDate || !this.taskManager.CreatedDate) return true;

    const due = new Date(this.taskManager.DueDate);
    const created = new Date(this.taskManager.CreatedDate);

    return due >= created;
  }

  // Format date
  formatDate(date: string | Date): string {
    const d = new Date(date);
    const month = ('0' + (d.getMonth() + 1)).slice(-2);
    const day = ('0' + d.getDate()).slice(-2);
    return `${d.getFullYear()}-${month}-${day}`;
  }
}
