import { Component, EventEmitter, OnInit, Output } from '@angular/core';
import { Router } from '@angular/router';
import { TaskManager } from 'src/app/models/taskManager';
import { TaskmanagerService } from 'src/app/services/taskmanager.service';

@Component({
  selector: 'app-tasks',
  templateUrl: './tasks.component.html',
  styleUrls: ['./tasks.component.scss'],
})
export class TasksComponent implements OnInit {
  // tasks list
  taskManagerList: TaskManager[] = [];
  // add - edit task
  isNewTask: boolean = false;
  // selected task id
  selectedTaskId: number = 0;
  // remove task
  isComplete: boolean = false;
  // Sort task
  IsAccending: boolean = false;
  sortBy: boolean = false;
  sortByName: string = 'ASC';

  constructor(private taskmanagerService: TaskmanagerService) {}

  ngOnInit(): void {
    // Initialization
    this.GetAllTasks();
  }

  // Get all task list
  GetAllTasks() {
    this.taskmanagerService.GetTaskList().subscribe((data) => {
      if (data) {
        this.taskManagerList = <TaskManager[]>data;
      }
    });
  }

  // Add task
  addTask() {
    // add task
    this.isNewTask = !this.isNewTask;
    // navigate to add task component
    // this.router.navigate(['/newtask']);
  }

  // Set task to complete
  markAsCompleted(taskManager: TaskManager) {
    this.taskmanagerService
      .CompleteTasksById(taskManager.Id)
      .subscribe((data) => {
        this.isComplete = <boolean>data;
        if (this.isComplete) {
          this.GetAllTasks();
        }
      });
  }

  // delete selected task
  deleteTask(taskManager: TaskManager) {
    this.taskmanagerService
      .RemoveTasksById(taskManager.Id)
      .subscribe((data) => {
        this.isComplete = <boolean>data;
        if (this.isComplete) {
          this.GetAllTasks();
        }
      });
  }

  // edit tasks
  editTask(taskManager: TaskManager) {
    this.selectedTaskId = taskManager.Id;
    this.isNewTask = true;
  }

  // Emit component
  onMessageReceived(event: boolean) {
    this.isNewTask = event;
    this.GetAllTasks();
  }

  // Sort by title
  onSort(columnName: string) {
    debugger;
    // Identify sort
    if (this.sortByName == 'ASC') {
      this.sortByName = 'DESC';
    } else if (this.sortByName == 'DESC') {
      this.sortByName = 'ASC';
    }

    // Sort data
    this.taskmanagerService
      .GetSortAllTasks(columnName, this.sortByName)
      .subscribe((data) => {
        this.taskManagerList = <TaskManager[]>data;
      });
  }
}
