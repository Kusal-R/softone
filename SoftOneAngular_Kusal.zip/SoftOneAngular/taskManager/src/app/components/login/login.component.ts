import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { TaskmanagerService } from 'src/app/services/taskmanager.service';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.scss'],
})
export class LoginComponent implements OnInit {
  // attributes
  username = '';
  password = '';
  // check login status
  isLogin: boolean | undefined = true;

  // constructor
  constructor(
    private taskmanagerService: TaskmanagerService,
    private router: Router
  ) {}

  ngOnInit(): void {}

  // validate logins
  login() {
    if (this.username !== '' && this.password !== '') {
      // Redirect to dashboard or save token.
      this.taskmanagerService
        .ValidateUser(this.username, this.password)
        .subscribe((data) => {
          this.isLogin = <boolean>data;
          if (this.isLogin) {
            this.router.navigate(['/tasks']);
          } else {
            this.username = '';
            this.password = '';
            this.isLogin = false;
          }
        });
    } else {
      console.log(this.isLogin);
    }
  }
}
