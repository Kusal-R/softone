export interface TaskManager {
  Id: number;
  Title: string;
  Description?: string;
  IsCompleted: boolean;
  CreatedDate: string;
  DueDate: string;
}
