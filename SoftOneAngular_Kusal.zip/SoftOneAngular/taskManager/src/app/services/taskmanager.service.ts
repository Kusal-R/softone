import { HttpClient, HttpParams } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { TaskManager } from '../models/taskManager';
import { catchError } from 'rxjs';

@Injectable({
  providedIn: 'root',
})
export class TaskmanagerService {
  // API URL
  private GetAllTasksUrl = 'https://localhost:7171/api/taskmanager/GetAllTasks';
  private SetTasksUrl = 'https://localhost:7171/api/taskmanager/SetTasks';
  private GetAllTasksByIdUrl =
    'https://localhost:7171/api/taskmanager/GetAllTasksById';
  private RemoveTasksByIdUrl =
    'https://localhost:7171/api/taskmanager/RemoveTasksById';
  private CompleteTasksByIdUrl =
    'https://localhost:7171/api/taskmanager/CompleteTasksById';
  private ValidateUserUrl =
    'https://localhost:7171/api/taskmanager/ValidateUser';
  private GetSortAllTasksUrl =
    'https://localhost:7171/api/taskmanager/GetSortAllTasks';

  // constructor
  constructor(private http: HttpClient) {}

  // get task list
  GetTaskList() {
    let myparams = new HttpParams();
    let options = myparams.toString();

    return this.http
      .get<TaskManager[]>(this.GetAllTasksUrl, { params: myparams })
      .pipe(
        catchError((error) => {
          return this.handleError('GetTaskList', error);
        })
      );
  }

  // get task list
  GetTaskById(taskId: number) {
    let myparams = new HttpParams().set('taskId', taskId.toString());

    let options = myparams.toString();

    return this.http
      .get<TaskManager>(this.GetAllTasksByIdUrl, { params: myparams })
      .pipe(
        catchError((error) => {
          return this.handleError('GetTaskById', error);
        })
      );
  }

  // save tasks
  SaveTask(taskManager: TaskManager) {
    let myparams = new HttpParams();
    let options = myparams.toString();

    return this.http
      .post<boolean>(this.SetTasksUrl, taskManager, {
        params: myparams,
      })
      .pipe(
        catchError((error) => {
          return this.handleError('SaveTask', error);
        })
      );
  }

  // remove task
  RemoveTasksById(taskId: number) {
    let myparams = new HttpParams().set('taskId', taskId.toString());

    let options = myparams.toString();

    return this.http
      .get<boolean>(this.RemoveTasksByIdUrl, { params: myparams })
      .pipe(
        catchError((error) => {
          return this.handleError('GetTaskById', error);
        })
      );
  }

  // complete task
  CompleteTasksById(taskId: number) {
    let myparams = new HttpParams().set('taskId', taskId.toString());

    let options = myparams.toString();

    return this.http
      .get<boolean>(this.CompleteTasksByIdUrl, { params: myparams })
      .pipe(
        catchError((error) => {
          return this.handleError('GetTaskById', error);
        })
      );
  }

  // login details
  ValidateUser(userId: string, password: string) {
    let myparams = new HttpParams()
      .set('userId', userId.toString())
      .set('password', password.toString());

    let options = myparams.toString();

    return this.http
      .get<boolean>(this.ValidateUserUrl, { params: myparams })
      .pipe(
        catchError((error) => {
          return this.handleError('ValidateUser', error);
        })
      );
  }

  // get sort task list
  GetSortAllTasks(columnName: string, sortType: string) {
    let myparams = new HttpParams()
      .set('columnName', columnName.toString())
      .set('sortType', sortType.toString());
    let options = myparams.toString();
    debugger;
    return this.http
      .get<TaskManager[]>(this.GetSortAllTasksUrl, { params: myparams })
      .pipe(
        catchError((error) => {
          return this.handleError('GetSortAllTasks', error);
        })
      );
  }

  // Handling the error
  private handleError(methodName: string, exception: Error) {
    let errorMessage = methodName + ' ' + exception;
    return errorMessage;
  }
}
