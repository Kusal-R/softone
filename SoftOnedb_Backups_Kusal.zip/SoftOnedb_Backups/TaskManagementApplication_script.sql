USE [TaskManagementApplication]
GO
/****** Object:  StoredProcedure [dbo].[SetTasks]    Script Date: 5/11/2025 5:25:04 PM ******/
DROP PROCEDURE [dbo].[SetTasks]
GO
/****** Object:  StoredProcedure [dbo].[GetLoginDetails]    Script Date: 5/11/2025 5:25:04 PM ******/
DROP PROCEDURE [dbo].[GetLoginDetails]
GO
/****** Object:  StoredProcedure [dbo].[GetAllTasks]    Script Date: 5/11/2025 5:25:04 PM ******/
DROP PROCEDURE [dbo].[GetAllTasks]
GO
ALTER TABLE [dbo].[TaskManager] DROP CONSTRAINT [DF_TaskManager_IsDisabled]
GO
ALTER TABLE [dbo].[TaskManager] DROP CONSTRAINT [DF_TaskManager_DueDate]
GO
ALTER TABLE [dbo].[TaskManager] DROP CONSTRAINT [DF__TaskManag__Creat__25869641]
GO
ALTER TABLE [dbo].[TaskManager] DROP CONSTRAINT [DF__TaskManag__IsCom__24927208]
GO
ALTER TABLE [dbo].[TaskManager] DROP CONSTRAINT [DF_TaskManager_Description]
GO
ALTER TABLE [dbo].[TaskManager] DROP CONSTRAINT [DF_TaskManager_Title]
GO
ALTER TABLE [dbo].[LoginDetails] DROP CONSTRAINT [DF_LoginDetails_Password]
GO
ALTER TABLE [dbo].[LoginDetails] DROP CONSTRAINT [DF_LoginDetails_UserName]
GO
/****** Object:  Table [dbo].[TaskManager]    Script Date: 5/11/2025 5:25:04 PM ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[TaskManager]') AND type in (N'U'))
DROP TABLE [dbo].[TaskManager]
GO
/****** Object:  Table [dbo].[LoginDetails]    Script Date: 5/11/2025 5:25:04 PM ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[LoginDetails]') AND type in (N'U'))
DROP TABLE [dbo].[LoginDetails]
GO
/****** Object:  Table [dbo].[LoginDetails]    Script Date: 5/11/2025 5:25:04 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[LoginDetails](
	[Id] [int] IDENTITY(1,1) NOT NULL,
	[UserName] [nvarchar](50) NOT NULL,
	[Password] [nvarchar](50) NOT NULL,
 CONSTRAINT [PK_LoginDetails] PRIMARY KEY CLUSTERED 
(
	[Id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[TaskManager]    Script Date: 5/11/2025 5:25:04 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[TaskManager](
	[Id] [int] IDENTITY(1,1) NOT NULL,
	[Title] [nvarchar](255) NOT NULL,
	[Description] [nvarchar](max) NOT NULL,
	[IsCompleted] [bit] NOT NULL,
	[CreatedDate] [datetime] NOT NULL,
	[DueDate] [datetime] NOT NULL,
	[IsDisabled] [bit] NOT NULL,
 CONSTRAINT [PK__TaskMana__3214EC07269069EB] PRIMARY KEY CLUSTERED 
(
	[Id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO
SET IDENTITY_INSERT [dbo].[LoginDetails] ON 
GO
INSERT [dbo].[LoginDetails] ([Id], [UserName], [Password]) VALUES (1, N'Kusal', N'abc@1234')
GO
SET IDENTITY_INSERT [dbo].[LoginDetails] OFF
GO
SET IDENTITY_INSERT [dbo].[TaskManager] ON 
GO
INSERT [dbo].[TaskManager] ([Id], [Title], [Description], [IsCompleted], [CreatedDate], [DueDate], [IsDisabled]) VALUES (3, N'Complete project documentation', N'Finish writing API and architecture documentation.', 0, CAST(N'2025-05-09T00:00:00.000' AS DateTime), CAST(N'2025-05-27T00:00:00.000' AS DateTime), 0)
GO
INSERT [dbo].[TaskManager] ([Id], [Title], [Description], [IsCompleted], [CreatedDate], [DueDate], [IsDisabled]) VALUES (4, N'Fix login bug', N'Resolve issue with user authentication failure.', 1, CAST(N'2025-05-09T00:00:00.000' AS DateTime), CAST(N'2025-05-23T00:00:00.000' AS DateTime), 0)
GO
INSERT [dbo].[TaskManager] ([Id], [Title], [Description], [IsCompleted], [CreatedDate], [DueDate], [IsDisabled]) VALUES (5, N'Prepare sprint demo', N'Create demo presentation for the sprint review.', 0, CAST(N'2025-05-09T00:00:00.000' AS DateTime), CAST(N'2025-05-30T00:00:00.000' AS DateTime), 0)
GO
INSERT [dbo].[TaskManager] ([Id], [Title], [Description], [IsCompleted], [CreatedDate], [DueDate], [IsDisabled]) VALUES (6, N'Update Angular version', N'Upgrade Angular from 13 to 15 in the frontend.', 0, CAST(N'2025-05-09T22:17:01.140' AS DateTime), CAST(N'2025-05-09T22:17:01.140' AS DateTime), 0)
GO
INSERT [dbo].[TaskManager] ([Id], [Title], [Description], [IsCompleted], [CreatedDate], [DueDate], [IsDisabled]) VALUES (7, N'Refactor data access layer', N'Optimize repository pattern and improve performance.', 1, CAST(N'2025-05-09T22:17:01.140' AS DateTime), CAST(N'2025-05-09T22:17:01.140' AS DateTime), 0)
GO
INSERT [dbo].[TaskManager] ([Id], [Title], [Description], [IsCompleted], [CreatedDate], [DueDate], [IsDisabled]) VALUES (8, N'Finalize Project Report', N'Compile the latest updates, graphs, and budget analysis into the final version of the Q2 project report.', 0, CAST(N'2025-05-10T00:00:00.000' AS DateTime), CAST(N'2025-05-29T00:00:00.000' AS DateTime), 0)
GO
INSERT [dbo].[TaskManager] ([Id], [Title], [Description], [IsCompleted], [CreatedDate], [DueDate], [IsDisabled]) VALUES (9, N'Team Stand-up Meeting', N'Daily 15-minute sync with the development team to review progress and blockers.', 1, CAST(N'2025-05-16T00:00:00.000' AS DateTime), CAST(N'2025-05-28T00:00:00.000' AS DateTime), 0)
GO
INSERT [dbo].[TaskManager] ([Id], [Title], [Description], [IsCompleted], [CreatedDate], [DueDate], [IsDisabled]) VALUES (12, N'Complete project documentation', N'Finish writing API and architecture documentation.', 0, CAST(N'2025-05-09T00:00:00.000' AS DateTime), CAST(N'2025-05-28T00:00:00.000' AS DateTime), 0)
GO
SET IDENTITY_INSERT [dbo].[TaskManager] OFF
GO
ALTER TABLE [dbo].[LoginDetails] ADD  CONSTRAINT [DF_LoginDetails_UserName]  DEFAULT ('') FOR [UserName]
GO
ALTER TABLE [dbo].[LoginDetails] ADD  CONSTRAINT [DF_LoginDetails_Password]  DEFAULT ('') FOR [Password]
GO
ALTER TABLE [dbo].[TaskManager] ADD  CONSTRAINT [DF_TaskManager_Title]  DEFAULT ('') FOR [Title]
GO
ALTER TABLE [dbo].[TaskManager] ADD  CONSTRAINT [DF_TaskManager_Description]  DEFAULT ('') FOR [Description]
GO
ALTER TABLE [dbo].[TaskManager] ADD  CONSTRAINT [DF__TaskManag__IsCom__24927208]  DEFAULT ((0)) FOR [IsCompleted]
GO
ALTER TABLE [dbo].[TaskManager] ADD  CONSTRAINT [DF__TaskManag__Creat__25869641]  DEFAULT (getdate()) FOR [CreatedDate]
GO
ALTER TABLE [dbo].[TaskManager] ADD  CONSTRAINT [DF_TaskManager_DueDate]  DEFAULT (getdate()) FOR [DueDate]
GO
ALTER TABLE [dbo].[TaskManager] ADD  CONSTRAINT [DF_TaskManager_IsDisabled]  DEFAULT ((0)) FOR [IsDisabled]
GO
/****** Object:  StoredProcedure [dbo].[GetAllTasks]    Script Date: 5/11/2025 5:25:05 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
-- =============================================
-- Author:		Kusal Rathnayake
-- Create date: 09 May 2025
-- Description:	Get all tasks
-- =============================================
-- exec [dbo].[GetAllTasks] @Action='GET$SORT$DATA',@ColumnName='Title',@SortBy='DESC'
-- exec [dbo].[GetAllTasks] @Action='GET$ALL',@ColumnName='Title',@SortBy='DESC'
CREATE PROCEDURE [dbo].[GetAllTasks] 
	-- Add the parameters for the stored procedure here
	@Action	varchar(50) = '',
	@TaskId	int = 0,
	@ColumnName	varchar(50) = '',
	@SortBy	varchar(50) = ''
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;
	DECLARE @SQL NVARCHAR(MAX) = ''

    -- Insert statements for procedure here
	IF @Action = 'GET$ALL'
	BEGIN
		SELECT  [Id],
				[Title],
				[Description],
				[IsCompleted],
				[CreatedDate],
				[DueDate]
		FROM	[dbo].[TaskManager]
		WHERE	[IsDisabled] = CAST(0 AS BIT)
	END
	-- get task by id
	ELSE IF @Action ='GET$BYID'
	BEGIN
		SELECT  [Id],
				[Title],
				[Description],
				[IsCompleted],
				[CreatedDate],
				[DueDate]
		FROM	[dbo].[TaskManager]
		WHERE	[IsDisabled] = CAST(0 AS BIT)
		AND		[Id] = @TaskId
	END
	-- sortdata
	ELSE IF @Action ='GET$SORT$DATA'
	BEGIN		
		SET @SQL = ' SELECT  [Id],
					[Title],
					[Description],
					[IsCompleted],
					[CreatedDate],
					[DueDate]
			FROM	[dbo].[TaskManager]
			WHERE	[IsDisabled] = CAST(0 AS BIT) '

		SET @SQL = @SQL + ' ORDER BY ' + @ColumnName
		SET @SQL = @SQL +' '+ @SortBy 

		-- SELECT @SQL
		EXEC sp_executesql @Sql;
					
	END
END
GO
/****** Object:  StoredProcedure [dbo].[GetLoginDetails]    Script Date: 5/11/2025 5:25:05 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
-- =============================================
-- Author:		Kusal Rathnayake
-- Create date: 11 May 2025
-- Description:	Check loging details
-- =============================================
CREATE PROCEDURE [dbo].[GetLoginDetails] 
	-- Add the parameters for the stored procedure here
	@UserName nvarchar(50) = '',
	@Password nvarchar(50) = ''
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

    -- Insert statements for procedure here
	IF EXISTS ( 
	SELECT  [Id]			
	FROM	[dbo].[LoginDetails]
	WHERE	[UserName] = @UserName
	AND		[Password] = @Password)
	BEGIN
		SELECT CAST(1 AS BIT) AS [Result]
	END
	ELSE
	BEGIN
		SELECT CAST(0 AS BIT) AS [Result]
	END
END
GO
/****** Object:  StoredProcedure [dbo].[SetTasks]    Script Date: 5/11/2025 5:25:05 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
-- =============================================
-- Author:		Kusal Rathnayake
-- Create date: 09 May 2025
-- Description:	set tasks
-- =============================================
CREATE PROCEDURE [dbo].[SetTasks]
	-- Add the parameters for the stored procedure here
	@Action	varchar(50) = '',
	@Id	int = 0,
	@Title	nvarchar(255) = '',
	@Description	nvarchar(max) = '',
	@CreatedDate	varchar(50) = '',
	@DueDate	varchar(50) = '',
	@IsCompleted	bit = 0
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

    -- Insert statements for procedure here
	IF @Action = 'SET'
	BEGIN

		INSERT INTO [dbo].[TaskManager]
				   ([Title]
				   ,[Description]
				   ,[IsCompleted]
				   ,[CreatedDate]
				   ,[DueDate]
				   )
			 VALUES
				   (@Title
				   ,@Description
				   , CAST(@IsCompleted AS bit)
				   , CONVERT(datetime,@CreatedDate)
				   , CONVERT(datetime,@DueDate)
				   )

		SELECT SCOPE_IDENTITY() AS [Result];

	END
	-- EDIT TASK
	ELSE IF @Action ='EDIT'
	BEGIN

		UPDATE [dbo].[TaskManager]
		   SET [Title] = @Title
			  ,[Description] = @Description
			  ,[IsCompleted] = @IsCompleted
			  ,[CreatedDate] = CONVERT(datetime,@CreatedDate)
			  ,[DueDate] = CONVERT(datetime,@DueDate)
			  
		 WHERE [Id] = @Id

		 SELECT @Id AS [Result];

	END
	-- remove task
	ELSE IF @Action ='REMOVE$TASK'
	BEGIN
		DELETE FROM [dbo].[TaskManager]
		WHERE  [Id] = @Id

		SELECT @Id AS [Result];
	END
	--  complete task
	ELSE IF @Action = 'TASK$COMPLETE'
	BEGIN
		UPDATE [dbo].[TaskManager]
		SET	 [IsCompleted] = CAST( 1 AS BIT)
		WHERE  [Id] = @Id

		SELECT @Id AS [Result];
	END

END
GO
